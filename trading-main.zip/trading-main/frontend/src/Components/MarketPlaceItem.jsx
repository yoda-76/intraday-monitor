import React from "react";

const MarketPlaceItem = () => {
  return (
    <tr className="bg-[#262832]  border-2 border-[#212126]">
      <th>BankNift 2324</th>
      <td>139</td>
      <td>223</td>
      <td>0</td>
      <td>AudiTT</td>
      <td>130</td>
      <td>139</td>
    </tr>
  );
};

export default MarketPlaceItem;
